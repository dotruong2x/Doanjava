/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Navigator;

import Property.Student;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author NamTran
 */
public class Navigator {

    public static final String INDEX_FXML = "/Views/index.fxml";
    public static final String LIST_CLASS_FXML = "/Views/list_class.fxml";
    public static final String LIST_MARK_FXML = "/Views/list_mark.fxml";
    public static final String INSERT_STUDENT_FXML = "/Views/insert_student.fxml";
    public static final String INSERT_CLASS_FXML = "/Views/insert_class.fxml";
    public static final String INSERT_MARK_FXML = "/Views/insert_mark.fxml";
    public static final String UPDATE_STUDENT_FXML = "/Views/update_student.fxml";
    public static final String UPDATE_CLASS_FXML = "/Views/update_class.fxml";
    public static final String UPDATE_MARK_FXML = "/Views/update_mark.fxml";

//    private FXMLLoader loader;
    private Stage stage = null;

    private static Navigator nav = null;

    private Navigator() {

    }

    public static Navigator getInstance() {
        if (nav == null) {
            nav = new Navigator();
        }

        return nav;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public Stage getStage() {
        return stage;
    }

    private void goTo(String fxml) throws IOException {
//        this.loader = new FXMLLoader();
        
//        loader.setLocation(getClass().getResource(fxml));
//        Parent root = loader.load();
        Parent root = FXMLLoader.load(getClass().getResource(fxml));
        Scene scene = new Scene(root);
        this.stage.setScene(scene);
    }

    public void goToINDEX_FXML() throws IOException {
        this.goTo(INDEX_FXML);
    }

    public void goToINSERT_STUDENT_FXML(Student editStudent) throws IOException {
        this.goTo(INSERT_STUDENT_FXML);
    }

    public void goToLIST_CLASS_FXML() throws IOException {
        this.goTo(LIST_CLASS_FXML);
    }

    public void goToLIST_MARK_FXML() throws IOException {
        this.goTo(LIST_MARK_FXML);
    }

    public void goToINSERT_CLASS_FXML() throws IOException {
        this.goTo(INSERT_CLASS_FXML);
    }

    public void goToUPDATE_CLASS_FXML() throws IOException {
        this.goTo(UPDATE_CLASS_FXML);
    }

    public void goToINSERT_MARK_FXML() throws IOException {
        this.goTo(INSERT_MARK_FXML);
    }

    public void goToUPDATE_MARK_FXML() throws IOException {
        this.goTo(UPDATE_MARK_FXML);
    }
}
