/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Navigator.Navigator;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

/**
 *
 * @author ThuyLinh
 */
public class InsertController {

    @FXML
    private TextField tb_name;

    @FXML
    private TextField tb_DOB;

    @FXML
    private TextField tb_email;

    @FXML
    private ComboBox<?> combobox1;

    @FXML
    private Button btn_submit;

    @FXML
    void btn_backtoclass(ActionEvent event) throws IOException {
        Navigator.getInstance().goToLIST_CLASS_FXML();
    }

    @FXML
    void btn_backtomark(ActionEvent event) throws IOException {
        Navigator.getInstance().goToLIST_MARK_FXML();
    }

    @FXML
    void btn_backtostd(ActionEvent event) throws IOException {
        Navigator.getInstance().goToINDEX_FXML();
    }
}
