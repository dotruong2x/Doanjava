/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Navigator.Navigator;
import Property.Student;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 *
 * @author Thuy Linh
 */
public class IndexController {

    @FXML
    private TableView<Student> tv_Student;

    @FXML
    private TableColumn<Student, Integer> td_stdId;

    @FXML
    private TableColumn<Student, String> td_stdName;

    @FXML
    private TableColumn<Student, String> td_stdClass;

    @FXML
    private TableColumn<Student, String> td_stdDOB;

    @FXML
    private TableColumn<Student, String> td_stdEmail;
    
    @FXML
    private ComboBox<String> comboboxinsertstd;

    @FXML
    private Button btn_insert;

    @FXML
    private Button btn_update;

    @FXML
    private Button btn_delete;

    @FXML
    void btn_backtostd(ActionEvent event) {
        try {
            Navigator.getInstance().goToINDEX_FXML();
        } catch (IOException ex) {
            Logger.getLogger(IndexController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void btn_backtoclass(ActionEvent event) throws IOException {
        Navigator.getInstance().goToLIST_CLASS_FXML();
    }

    @FXML
    void btn_backtomark(ActionEvent event) throws IOException {
        Navigator.getInstance().goToLIST_MARK_FXML();
    }

    @FXML
    void btn_insert_std(ActionEvent event) throws IOException {
        Navigator.getInstance().goToINSERT_STUDENT_FXML(null);
    }

   
    @FXML
    void btn_deleteStd(ActionEvent event) throws SQLException {
        Student selectedStd = tv_Student.getSelectionModel().getSelectedItem();
        if (selectedStd == null) {
            selectStdWarning();
        } else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setHeaderText("Are you sure you want to delete the selected student?");
            alert.setTitle("Deleting a student");
            Optional<ButtonType> confirmationResponse
                    = alert.showAndWait();
            if (confirmationResponse.get() == ButtonType.OK) {
                Student deleteStd = tv_Student.getSelectionModel().getSelectedItem();
                boolean result = Student.delete(deleteStd);

                if (result) {
                    tv_Student.getItems().remove(selectedStd);
                    System.out.println("A student is deleted");
                }
            }
        }
    }

    @FXML
    public void initialize() throws SQLException {
        
        String dbUsername = "root";
        String dbPassword = "";
        String dbURL = "jdbc:mysql://localhost:3306/Student_manager?serverTimeZone=UTC";

        try {
            Connection conn = DriverManager.getConnection(dbURL, dbUsername, dbPassword);
            ResultSet rs = conn.createStatement().executeQuery("SELECT name FROM Class;");
            while (rs.next()) {
                comboboxinsertstd.getItems().addAll(rs.getString("name"));
            }
        } catch (SQLException ex) {
            System.err.println("Error" + ex);
        }

        System.out.println("#IndexController initialized!");
        tv_Student.setItems(Student.selectAll());

        td_stdId.setCellValueFactory(s -> s.getValue().getIdProperty());

        td_stdName.setCellValueFactory((student) -> {
            return student.getValue().getNameproperty();
        });

        td_stdClass.setCellValueFactory((student) -> {
            return student.getValue().getName_classProperty();
        });
        td_stdDOB.setCellValueFactory((student) -> {
            return student.getValue().getDOBProperty();
        });
        td_stdEmail.setCellValueFactory((student) -> {
            return student.getValue().getEmailproperty();
        });
    }

    public void selectStdWarning() {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Please select a student?");
        alert.setHeaderText("A student must be selected for the operation");
        alert.showAndWait();
    }
}
