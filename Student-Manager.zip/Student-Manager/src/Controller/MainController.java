/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Navigator.Navigator;
import java.io.IOException;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 *
 * @author NamTran
 */
public class MainController extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        try{
            primaryStage.setTitle("Student Manager");
        Navigator.getInstance().setStage(primaryStage);
        Navigator.getInstance().goToINDEX_FXML();
        primaryStage.show();
        } catch(IOException e){
            System.out.println(e);
        }
        
    }
    
    public static void main(String[] args) {
        launch(args);
    }
    
}
