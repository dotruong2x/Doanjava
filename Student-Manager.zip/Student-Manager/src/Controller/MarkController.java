/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Navigator.Navigator;
import Property.Mark;
import java.io.IOException;
import java.sql.SQLException;
import javafx.event.ActionEvent;

/**
 *
 * @author NamTran
 */

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class MarkController {

    @FXML
    private TableView<Mark> tv_mark;

    @FXML
    private TableColumn<Mark, Integer> tc_idStudent;

    @FXML
    private TableColumn<Mark, String> tc_name;

    @FXML
    private TableColumn<Mark, Double> tc_C;

    @FXML
    private TableColumn<Mark, Double> tc_HTML;

    @FXML
    private TableColumn<Mark, Double> tc_PHP;

    @FXML
    private TableColumn<Mark, Double> tc_JAVA;

    @FXML
    private TableColumn<Mark, Double> tc_average;

    @FXML
    private TableColumn< Mark, String> tc_grade;


    @FXML
    void btn_backtostd(ActionEvent event) throws IOException {
        Navigator.getInstance().goToINDEX_FXML();
    }
    
    @FXML
    void btn_backtoclass(ActionEvent event) throws IOException {
        Navigator.getInstance().goToLIST_CLASS_FXML();
    }

    @FXML
    void btn_backtomark(ActionEvent event) throws IOException {
        Navigator.getInstance().goToLIST_MARK_FXML();
    }
    
    @FXML
    void btn_insertclass(ActionEvent event) throws IOException {
        Navigator.getInstance().goToINSERT_CLASS_FXML();
    }
    
    @FXML
    void btn_updateclass(ActionEvent event) throws IOException {
        Navigator.getInstance().goToUPDATE_CLASS_FXML();
    }

    @FXML
    void btn_insertmark(ActionEvent event) throws IOException {
        Navigator.getInstance().goToINSERT_MARK_FXML();
    }

    @FXML
    void btn_updatemark(ActionEvent event) throws IOException {
        Navigator.getInstance().goToUPDATE_MARK_FXML();
    }
    
    @FXML 
    public void initialize() throws SQLException{
        System.out.println("MarkController initialize");
        tv_mark.setItems(Mark.selectAllMark());
        
        
        tc_idStudent.setCellValueFactory(m -> m.getValue().getIdProperty());
        tc_name.setCellValueFactory(m -> m.getValue().getNameProperty());
        tc_C.setCellValueFactory(m -> m.getValue().getCProperty());
        tc_HTML.setCellValueFactory(m -> m.getValue().getHtmlProperty());
        tc_PHP.setCellValueFactory(m -> m.getValue().getPhpProperty());
        tc_JAVA.setCellValueFactory(m -> m.getValue().getJavaProperty());
        tc_average.setCellValueFactory(m -> m.getValue().getAvgProperty());
        tc_grade.setCellValueFactory(m -> m.getValue().getGradeProperty());
                  
    }
    
}
