/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Navigator.Navigator;
import Property.Class_std;
import java.io.IOException;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 *
 * @author NamTran
 */
public class ClassController {
    
    @FXML
    private TableView<Class_std> tv_class;

    @FXML
    private TableColumn<Class_std, Integer> tc_no;

    @FXML
    private TableColumn<Class_std, String> tc_className;

    @FXML
    private TableColumn<Class_std, String> tc_teacher;
    
    @FXML
    void btn_backtostd(ActionEvent event) throws IOException {
        Navigator.getInstance().goToINDEX_FXML();
    }
    
    @FXML
    void btn_backtoclass(ActionEvent event) throws IOException {
        Navigator.getInstance().goToLIST_CLASS_FXML();
    }

    @FXML
    void btn_backtomark(ActionEvent event) throws IOException {
        Navigator.getInstance().goToLIST_MARK_FXML();
    }
    
    @FXML
    void btn_insert_std(ActionEvent event) throws IOException {
        Navigator.getInstance().goToINSERT_STUDENT_FXML(null);
    }
    
   
    
    @FXML
    void btn_insertclass(ActionEvent event) throws IOException {
        Navigator.getInstance().goToINSERT_CLASS_FXML();
    }
    
    @FXML
    void btn_updateclass(ActionEvent event) throws IOException {
        Navigator.getInstance().goToUPDATE_CLASS_FXML();
    }

    @FXML
    void btn_insertmark(ActionEvent event) throws IOException {
        Navigator.getInstance().goToINSERT_MARK_FXML();
    }

    @FXML
    void btn_updatemark(ActionEvent event) throws IOException {
        Navigator.getInstance().goToUPDATE_MARK_FXML();
    }
    
    
    
     @FXML
    public void initialize() throws SQLException {

        System.out.println("#ClassController initialized!");
        
        tv_class.setItems(Class_std.selectAll());
         tc_no.setCellValueFactory(c -> c.getValue().getIdProperty());

        tc_className.setCellValueFactory((c) -> {
            return c.getValue().getNameProperty();
        });
        
        tc_teacher.setCellValueFactory((c) -> {
             return c.getValue().getTeacherProperty();
        });

              
    }

}
