/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Property;

import DB.DBService;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Thuy Linh
 */
public class Student {

   
    private ObjectProperty<Integer> id;
    private StringProperty name;
    private StringProperty name_class;
    private StringProperty DOB;
    private StringProperty email;

    public Student() {
        id = new SimpleObjectProperty<>();
        name = new SimpleStringProperty();
        name_class = new SimpleStringProperty();
        DOB = new SimpleStringProperty();
        email = new SimpleStringProperty();
    }

    public ObjectProperty<Integer> getIdProperty() {
        return id;
    }

    public StringProperty getNameproperty() {
        return this.name;
    }

    public StringProperty getName_classProperty() {
        return name_class;
    }

    public StringProperty getDOBProperty() {
        return this.DOB;
    }

    public StringProperty getEmailproperty() {
        return this.email;
    }

    public Integer getId() {
        return id.get();
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getName() {
        return name.get();
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public String getName_class() {
        return name_class.get();
    }

    public void setName_class(String name_class) {
        this.name_class.set(name_class);
    }

    public String getDOB() {
        return DOB.get();
    }

    public void setDOB(String DOB) {
        this.DOB.set(DOB);
    }

    public String getEmail() {
        return email.get();
    }

    public void setEmail(String email) {
        this.email.set(email);
    }

    public static ObservableList<Student> selectAll() throws SQLException {
        ObservableList<Student> students = FXCollections.observableArrayList();

        try (
                Connection conn = DBService.getConnection();
                Statement sttm = conn.createStatement();
                ResultSet rs = sttm.executeQuery("SELECT s.Id_student , s.Name , c.Name , s.DOB , s.Email  FROM Student as s JOIN Class as c ON s.Id_class = c.Id_class;"); // ResultSet rs = sttm.executeQuery("SELECT * From Student;");               
                ) {
            int index = 1;
            while (rs.next()) {
                
                Student s = new Student();
                s.setId(index);
                s.setName(rs.getString("Name"));
                s.setName_class(rs.getString("c.Name"));
                s.setDOB(rs.getString("DOB"));
                s.setEmail(rs.getString("Email"));

                students.add(s);
                index ++;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return students;
    }

    public static boolean delete(Student deleteStd) throws SQLException {
        String sql = "Delete from Mark WHERE Id_student = ? ";
         try (
                Connection conn = DBService.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql );
                ){
            System.out.println(deleteStd.getId());
            stmt.setInt(1, deleteStd.getId());
            
          
        } catch (Exception e){
            System.err.println(e);
            return false;
        }
        String sql2 = "Delete from Student WHERE Id_student = ? ";
        
        try (
                Connection conn = DBService.getConnection();
                PreparedStatement stmt2 = conn.prepareStatement(sql2 );
                ){
            System.out.println(deleteStd.getId());
            stmt2.setInt(1, deleteStd.getId());
            
            int rowDeleted = stmt2.executeUpdate();
            if(rowDeleted == 1){
                return true;
            }else {               
                System.err.println("No student deleted");
                return false;
            }
        } catch (Exception e){
            System.err.println(e);
            return false;
        }
    }

}
