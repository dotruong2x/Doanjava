/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Property;

import DB.DBService;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Thuy Linh
 */
public class Class_std {

   
    private ObjectProperty<Integer> id;
    private StringProperty name;
    private StringProperty teacher;
    private ObjectProperty<Integer> id_teacher;
    
     public Class_std(){
        id = new SimpleObjectProperty<>();
        name = new SimpleStringProperty();
        teacher = new SimpleStringProperty();
        id_teacher = new SimpleObjectProperty<>();
    }

    public ObjectProperty<Integer> getIdProperty() {
        return id;
    }
    public StringProperty getNameProperty() {
        return name;
    }
    public ObjectProperty<Integer> getId_teacherProperty() {
        return id_teacher;
    }

    public StringProperty getTeacherProperty() {
        return teacher;
    }
    
    public Integer getId(){
        return id.get() ;
    }   
    public void setId(int id){
        this.id.set(id) ;
    }
    public String getName(){
        return name.get() ;
    }
    public void setName(String name){
        this.name.set(name);
    }
    
    public String getTeacher(){
        return teacher.get() ;
    }
    public void setTeacher(String teacher){
        this.teacher.set(teacher);
    }
    
     public Integer getId_teacher(){
        return id_teacher.get() ;
    }
    public void setId_teacher(int id_class){
        this.id_teacher.set(id_class) ;
    }
     
    public static ObservableList<Class_std> selectAll() throws SQLException {
        ObservableList<Class_std> classes = FXCollections.observableArrayList();

        try (
                Connection conn = DBService.getConnection();
                Statement sttm = conn.createStatement();
                ResultSet rs = sttm.executeQuery("SELECT c.Id_class , c.Name , t.Name FROM Class as c JOIN Teacher as t where c.Id_teacher = t.Id_teacher ");             
                ) {
            int index = 1;
            while (rs.next()) {
                Class_std c  =  new Class_std();
                c.setId(index);
                c.setName(rs.getString("c.Name"));
                c.setTeacher(rs.getString("t.Name"));
                
                classes.add(c);
                index ++;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return classes;
    }
    
    
    }
     
    

