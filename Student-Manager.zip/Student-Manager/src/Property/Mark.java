/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Property;

import DB.DBService;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Observable;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author ThuyLinh
 */
public class Mark {

    private ObjectProperty<Integer> id;
    private StringProperty name;
    private ObjectProperty<Double> c;
    private ObjectProperty<Double> html;
    private ObjectProperty<Double> php;
    private ObjectProperty<Double> java;
    private ObjectProperty<Double> avg;
    private ObjectProperty<Integer> id_student;
    private StringProperty grade;

    public Mark() {
        id = new SimpleObjectProperty<>();
        name = new SimpleStringProperty();
        c = new SimpleObjectProperty<>();
        html = new SimpleObjectProperty<>();
        php = new SimpleObjectProperty<>();
        java = new SimpleObjectProperty<>();
        avg = new SimpleObjectProperty<>();
        id_student = new SimpleObjectProperty<>();
        grade = new SimpleStringProperty();
    }

    public ObjectProperty<Integer> getIdProperty() {
        return id;
    }

    public StringProperty getNameProperty() {
        return name;
    }

    public ObjectProperty<Double> getCProperty() {
        return c;
    }

    public ObjectProperty<Double> getHtmlProperty() {
        return html;
    }

    public ObjectProperty<Double> getPhpProperty() {
        return php;
    }

    public ObjectProperty<Double> getJavaProperty() {
        return java;
    }
    
    public ObjectProperty<Double> getAvgProperty() {
         return avg  ;
         
    }

    public ObjectProperty<Integer> getId_studentProperty() {
        return id_student;
    }
    
    public StringProperty getGradeProperty() {
        return grade;
    }
    

    
    public Integer getId() {
        return id.get();
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getName() {
        return name.get();
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public Double getC() {
        return c.get();
    }

    public void setC(double c) {
        this.c.set(c);
    }

    public Double getHtml() {
        return html.get();
    }

    public void setHtml(double html) {
        this.html.set(html);
    }

    public Double getPhp() {
        return php.get();
    }

    public void setPhp(double php) {
        this.php.set(php);
    }

    public Double getJava() {
        return java.get();
    }

    public void setJava(double java) {
        this.java.set(java);
    }
    
    public Double getAvg() {
        return avg.get();
    }

    public void setAvg(double avg) {
       this.avg.set(avg);
    }

    public Integer getId_student() {
        return id_student.get();
    }

    public void setId_student(int id_student) {
        this.id_student.set(id_student);
    }
    
    public String getGrade() {
        return grade.get();
    }

    public void setGrade(String grade) {
        this.grade.set(grade);
    }
    public static ObservableList<Mark> selectAllMark() throws SQLException {
        ObservableList<Mark> marks = FXCollections.observableArrayList();
        try (
                Connection conn = DBService.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("Select m.Id_mark , s.Name , m.Mark, m.Id_subject  from Mark as m join Student as s on m.Id_student = s.Id_student;");) {
            int index = 1;
            while (rs.next()) {
                Mark m = new Mark();
                if (marks.size() <= 0) {
                    System.out.println(0);
                    m.setId(index);
                    m.setName(rs.getString("s.Name"));
                    if (rs.getInt("m.Id_subject") == 1) {
                        m.setC(rs.getInt("m.mark"));
                    } else if (rs.getInt("m.Id_subject") == 2) {
                        m.setHtml(rs.getInt("m.mark"));
                    } else if (rs.getInt("m.Id_subject") == 3) {
                        m.setPhp(rs.getInt("m.mark"));
                    } else if (rs.getInt("m.Id_subject") == 4) {
                        m.setJava(rs.getInt("m.mark"));
                    }
                    index++;
                    marks.add(m);
                } else {
                    int temp = 0;
                    for (Mark mark : marks) {
                        if (mark.getName().equals(rs.getString("s.Name"))) {
                            System.out.println(1);
                            if (rs.getInt("m.Id_subject") == 1) {
                                mark.setC(rs.getInt("m.mark"));
                            } else if (rs.getInt("m.Id_subject") == 2) {
                                mark.setHtml(rs.getInt("m.mark"));
                            } else if (rs.getInt("m.Id_subject") == 3) {
                                mark.setPhp(rs.getInt("m.mark"));
                            } else if (rs.getInt("m.Id_subject") == 4) {
                                mark.setJava(rs.getInt("m.mark"));
                            }
                            temp += 1;
                            break;
                        }
                    }
                    if (temp <= 0) {
                        System.out.println("Temp" + temp);
                        System.out.println(2);
                        m.setId(index);
                        m.setName(rs.getString("s.Name"));
                        if (rs.getInt("m.Id_subject") == 1) {
                            m.setC(rs.getInt("m.mark"));
                        } else if (rs.getInt("m.Id_subject") == 2) {
                            m.setHtml(rs.getInt("m.mark"));
                        } else if (rs.getInt("m.Id_subject") == 3) {
                            m.setPhp(rs.getInt("m.mark"));
                        } else if (rs.getInt("m.Id_subject") == 4) {
                            m.setJava(rs.getInt("m.mark"));
                        }
                        index++;
                        marks.add(m);
                    }
                }
            }
            for (Mark mark : marks) {
                mark.setAvg((mark.getC() + mark.getHtml() + mark.getPhp() + mark.getJava())/4);
                if(mark.getAvg()>= 9){
                    mark.setGrade("Giỏi");
                }else
                if(mark.getAvg()>= 8){
                    mark.setGrade("khá");
                }else
                if(mark.getAvg()>= 5){
                    mark.setGrade("trung bình");
                }else
                if(mark.getAvg()<5){
                    mark.setGrade("trượt");
                }
            }
            
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println(marks);
        return marks;
        
    }
}
